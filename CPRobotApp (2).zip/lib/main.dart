import 'package:flutter/material.dart';
import 'package:flutterapp/cprobotappapp/generatedframe1widget/GeneratedFrame1Widget.dart';
import 'package:flutterapp/cprobotappapp/generatedframe2widget/GeneratedFrame2Widget.dart';
import 'package:flutterapp/cprobotappapp/generatedframe3widget/GeneratedFrame3Widget.dart';

void main() {
  runApp(CPRobotAppApp());
}

class CPRobotAppApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedFrame1Widget',
      routes: {
        '/GeneratedFrame1Widget': (context) => GeneratedFrame1Widget(),
        '/GeneratedFrame2Widget': (context) => GeneratedFrame2Widget(),
        '/GeneratedFrame3Widget': (context) => GeneratedFrame3Widget(),
      },
    );
  }
}
